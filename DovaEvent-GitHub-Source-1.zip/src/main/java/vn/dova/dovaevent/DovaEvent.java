package vn.dova.dovaevent;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;\nimport org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.ScheduledTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public final class DovaEvent extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, InputState> input = new ConcurrentHashMap<>();
    private final Map<String, EventData> events = new LinkedHashMap<>();
    private final Map<UUID, String> editing = new ConcurrentHashMap<>();
    private ScheduledTask ticker;
    private long lastBroadcastSecond = Long.MIN_VALUE;

    private record InputState(String stage, String eventId) {}
    private static final class EventData {
        String id, name;
        long startAt;
        EventData(String id, String name, long startAt) { this.id=id; this.name=name; this.startAt=startAt; }
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("event")).setExecutor(this);
        Objects.requireNonNull(getCommand("dova")).setExecutor(this);
        Objects.requireNonNull(getCommand("dovaevent")).setExecutor(this);
        ticker = getServer().getGlobalRegionScheduler().runAtFixedRate(this, task -> tick(), 1L, 20L);
        getLogger().info("================================");
        getLogger().info("DovaEvent - Quan ly su kien");
        getLogger().info("Build by Truongnho_em");
        getLogger().info("Ho tro Folia 1.21.11");
        getLogger().info("================================");
    }

    @Override public void onDisable() { if (ticker != null) ticker.cancel(); }

    private String msg(String key) {
        String lang = getConfig().getString("language", "vi");
        if ("en".equalsIgnoreCase(lang)) {
            return switch (key) {
                case "help" -> "&eCommands: &a/event&e list events; &a/event admin&e manage events; &a/dova help&e help.";
                case "no-events" -> "&cThere are no events yet.";
                case "chat-name" -> "&eType the event name in chat. Type &ccancel &eto cancel.";
                case "chat-time" -> "&eEnter start time in seconds (example: 300). Type &ccancel &eto cancel.";
                case "invalid-time" -> "&cEnter a number of seconds greater than zero.";
                case "cancelled" -> "&cAction cancelled.";
                case "saved" -> "&aEvent saved.";
                case "no-permission" -> "&cYou do not have permission.";
                default -> getConfig().getString("messages." + key, key);
            };
        }
        return getConfig().getString("messages." + key, key);
    }
    private Component c(String s) { return Component.text(color(s)); }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private void tell(Player p, String s) { p.sendMessage(c(getConfig().getString("prefix", "&c[DovaEvent]&r ") + s)); }
    private ItemStack item(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat); ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        if (lore.length > 0) meta.lore(Arrays.stream(lore).map(this::c).toList());
        it.setItemMeta(meta); return it;
    }
    private Inventory menu(String title, int size) { return Bukkit.createInventory(null, size, c(title)); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Lenh nay chi dung trong game."); return true; }
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("dova")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("help")) { tell(p, msg("help")); return true; }
            if (args[0].equalsIgnoreCase("event")) {
                if (args.length > 1 && args[1].equalsIgnoreCase("admin")) openAdmin(p);
                else openPlayerMenu(p);
                return true;
            }
        }
        if (cmd.equals("dovaevent") || (args.length > 0 && args[0].equalsIgnoreCase("admin"))) {
            if (!isAdmin(p)) { tell(p, msg("no-permission")); return true; }
            openAdmin(p); return true;
        }
        openPlayerMenu(p);
        return true;
    }
    private boolean isAdmin(Player p) { return p.hasPermission("dovaevent.admin") || p.isOp(); }

    private void openAdmin(Player p) {
        Inventory inv = menu("&8DovaEvent &7- &fQuản lý", 27);
        inv.setItem(13, item(Material.CHEST, "&aTẠO EVENT", "&7Nhấn để tạo sự kiện mới"));
        inv.setItem(11, item(Material.BOOK, "&eDanh sách sự kiện", "&7Số sự kiện: " + events.size(), "&7Nhấn để xem/chỉnh sửa"));
        inv.setItem(22, item(Material.BARRIER, "&cĐóng"));
        p.openInventory(inv);
    }
    private void openEventList(Player p, boolean admin) {
        int size = 54; Inventory inv = menu(admin ? "&8Chọn sự kiện để chỉnh sửa" : "&8Sự kiện đang có", size);
        int slot = 0;
        for (EventData e : events.values()) {
            if (slot >= 45) break;
            long sec = Math.max(0, (e.startAt - System.currentTimeMillis()) / 1000);
            inv.setItem(slot++, item(admin ? Material.WRITABLE_BOOK : Material.PAPER,
                    "&f" + e.name, "&7Bắt đầu sau: &b" + duration(sec), admin ? "&eNhấn để chỉnh sửa" : "&aNhấn để xem thời gian"));
        }
        inv.setItem(49, item(Material.BARRIER, "&cQuay lại"));
        p.openInventory(inv);
    }
    private void openEdit(Player p, EventData e) {
        editing.put(p.getUniqueId(), e.id);
        Inventory inv = menu("&8Chỉnh sửa: " + e.name, 27);
        inv.setItem(11, item(Material.PAPER, "&eTên sự kiện", "&7Hiện tại: &f" + e.name, "&eNhấn để đổi tên"));
        inv.setItem(15, item(Material.CLOCK, "&eThời gian bắt đầu", "&7Nhấn để đặt lại số giây"));
        inv.setItem(22, item(Material.LIME_STAINED_GLASS_PANE, "&aXÁC NHẬN"));
        inv.setItem(18, item(Material.RED_STAINED_GLASS_PANE, "&cQuay lại menu chính"));
        p.openInventory(inv);
    }
    private void beginName(Player p) {
        input.put(p.getUniqueId(), new InputState("create-name", ""));
        p.closeInventory(); tell(p, msg("chat-name"));
    }
    private void beginTime(Player p, String id) {
        input.put(p.getUniqueId(), new InputState("time", id));
        p.closeInventory(); tell(p, msg("chat-time"));
    }

    @EventHandler public void onChat(AsyncChatEvent event) {
        Player p = event.getPlayer(); InputState state = input.get(p.getUniqueId());
        if (state == null) return;
        event.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        p.getScheduler().run(this, task -> {
            if (text.equalsIgnoreCase("cancel")) { input.remove(p.getUniqueId()); tell(p, msg("cancelled")); return; }
            if (state.stage.equals("create-name")) {
                if (text.isBlank()) { tell(p, msg("chat-name")); return; }
                String id = UUID.randomUUID().toString();
                EventData e = new EventData(id, text, System.currentTimeMillis() + getConfig().getLong("default-start-seconds", 300) * 1000L);
                events.put(id, e); input.put(p.getUniqueId(), new InputState("create-time", id));
                tell(p, msg("chat-time"));
            } else if (state.stage.equals("create-time") || state.stage.equals("time")) {
                long seconds;
                try { seconds = Long.parseLong(text); } catch (NumberFormatException ex) { tell(p, msg("invalid-time")); return; }
                if (seconds <= 0) { tell(p, msg("invalid-time")); return; }
                EventData e = events.get(state.eventId);
                if (e == null) { input.remove(p.getUniqueId()); return; }
                e.startAt = System.currentTimeMillis() + seconds * 1000L;
                input.remove(p.getUniqueId());
                if (state.stage.equals("create-time")) openEdit(p, e);
                else openEdit(p, e);
                tell(p, msg("saved"));
            } else if (state.stage.equals("rename")) {
                EventData e = events.get(state.eventId);
                if (e != null && !text.isBlank()) e.name = text;
                input.remove(p.getUniqueId()); if (e != null) openEdit(p, e);
            }
        }, null);
    }

    @EventHandler public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(e.getView().title());
        if (!title.contains("DovaEvent") && !title.contains("sự kiện") && !title.contains("Sự kiện")
                && !title.contains("Chọn sự kiện") && !title.contains("Chỉnh sửa:")) return;
        e.setCancelled(true);
        int slot = e.getRawSlot();
        if (title.contains("Quản lý")) {
            if (slot == 13) beginName(p);
            else if (slot == 11) openEventList(p, true);
            else if (slot == 22) p.closeInventory();
        } else if (title.contains("Chọn sự kiện")) {
            if (slot == 49) openAdmin(p);
            else {
                int index = slot;
                if (index >= 0 && index < events.size()) {
                    EventData ev = new ArrayList<>(events.values()).get(index);
                    openEdit(p, ev);
                }
            }
        } else if (title.contains("Chỉnh sửa:")) {
            String id = editing.get(p.getUniqueId()); EventData ev = events.get(id);
            if (slot == 18) openAdmin(p);
            else if (ev != null && slot == 11) {
                input.put(p.getUniqueId(), new InputState("rename", id)); p.closeInventory(); tell(p, msg("chat-name"));
            } else if (ev != null && slot == 15) beginTime(p, id);
            else if (ev != null && slot == 22) { p.closeInventory(); announceCreated(ev); tell(p, msg("saved")); }
        } else {
            if (slot == 49) p.closeInventory();
            else if (slot >= 0 && slot < 45) {
                int index = slot;
                if (index < events.size()) {
                    EventData ev = new ArrayList<>(events.values()).get(index);
                    tell(p, "&e" + ev.name + "&7: còn &b" + duration(Math.max(0, (ev.startAt-System.currentTimeMillis())/1000)) + "&7.");
                    p.closeInventory();
                }
            }
        }
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        if (!getConfig().getBoolean("plugin-introduction.enabled", true)) return;
        Player p = e.getPlayer();
        List<String> lines = getConfig().getStringList("plugin-introduction.lines");
        p.getScheduler().runDelayed(this, task -> {
            for (String line : lines) p.sendMessage(c(line));
        }, null, 20L);
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { input.remove(e.getPlayer().getUniqueId()); editing.remove(e.getPlayer().getUniqueId()); }

    private void openPlayerMenu(Player p) {
        if (events.isEmpty()) { tell(p, msg("no-events")); return; }
        openEventList(p, false);
    }
    private void announceCreated(EventData e) {
        if (!getConfig().getBoolean("broadcast-created", true)) return;
        String message = msg("created").replace("{event}", e.name).replace("{time}", duration(Math.max(0, (e.startAt-System.currentTimeMillis())/1000)));
        Bukkit.broadcast(c(getConfig().getString("prefix", "&c[DovaEvent]&r ") + message));
    }
    private void tick() {
        long now = System.currentTimeMillis();
        for (EventData e : events.values()) {
            long sec = Math.max(0, (e.startAt - now) / 1000);
            if (sec == 60 || sec == 30 || sec == 10 || sec == 5 || sec == 3 || sec == 2 || sec == 1) {
                if (lastBroadcastSecond != sec) {
                    String m = msg("upcoming").replace("{event}", e.name);
                    Bukkit.getGlobalRegionScheduler().run(this, task -> Bukkit.broadcast(c(getConfig().getString("prefix", "&c[DovaEvent]&r ") + m)));
                    lastBroadcastSecond = sec;
                }
            }
            if (sec > 0 && sec <= 60 && getConfig().getBoolean("countdown-actionbar", true)) {
                String bar = color("&e" + e.name + " &7bắt đầu sau &b" + duration(sec));
                for (Player p : Bukkit.getOnlinePlayers()) p.getScheduler().run(this, task -> p.sendActionBar(Component.text(bar)), null);
            }
        }
    }
    private String duration(long sec) {
        long h=sec/3600, m=(sec%3600)/60, s=sec%60;
        if (h>0) return h+"g "+m+"p "+s+"s";
        if (m>0) return m+"p "+s+"s";
        return s+"s";
    }
}
